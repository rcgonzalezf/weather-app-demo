[![Build Status](https://travis-ci.org/rcgonzalezf/weather-app-demo.svg?branch=feature%2Ftravis-ci)](https://travis-ci.org/rcgonzalezf/weather-app-demo) 
[![codecov](https://codecov.io/gh/rcgonzalezf/weather-app-demo/branch/master/graph/badge.svg)](https://codecov.io/gh/rcgonzalezf/weather-app-demo)


# weather-app-demo


Sample of an app consuming the OpenWeatherMap without using 3rd party libraries (only at commit https://github.com/rcgonzalezf/weather-app-demo/commit/ff85c9d4979f04cf0e19074d334139b73d8fcb51 )

If the device doesn't have GPS enabled or GPS permissions or Internet connection we try to get the
latest dataset that we managed to save.
