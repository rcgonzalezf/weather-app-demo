package org.rcgonzalezf.weather;

import android.support.test.filters.SmallTest;
import android.support.test.runner.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
@SmallTest
public class DummyTest {

  @Test public void dummyTest() {
    assertEquals(4, 2 + 2);
  }
}
