package rcgonzalezf.org.weather.common;

public interface PermissionResultListener {

  void onSuccess();
  void onFailure();

}
