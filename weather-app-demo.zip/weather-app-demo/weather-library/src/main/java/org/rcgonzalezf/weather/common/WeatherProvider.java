package org.rcgonzalezf.weather.common;

public enum WeatherProvider {
  OpenWeather,
}
