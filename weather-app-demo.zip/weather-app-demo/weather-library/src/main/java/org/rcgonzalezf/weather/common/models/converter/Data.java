package org.rcgonzalezf.weather.common.models.converter;

public interface Data {
}
