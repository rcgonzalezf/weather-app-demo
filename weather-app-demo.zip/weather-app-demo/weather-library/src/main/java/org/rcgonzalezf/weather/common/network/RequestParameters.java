package org.rcgonzalezf.weather.common.network;

public interface RequestParameters {
}
