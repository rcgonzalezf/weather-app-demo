package org.rcgonzalezf.weather.openweather.model;

// Gson
@SuppressWarnings("unused") public class Main {

  private long humidity;

  private double temp;

  public long getHumidity() {
    return humidity;
  }

  public double getTemp() {
    return temp;
  }
}
