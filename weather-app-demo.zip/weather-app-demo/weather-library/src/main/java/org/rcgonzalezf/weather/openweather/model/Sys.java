package org.rcgonzalezf.weather.openweather.model;

public class Sys {

  public String country;
}
