package org.rcgonzalezf.weather.openweather.model;

// Gson
@SuppressWarnings("unused") public class Weather {
  private int id;

  private String description;

  public int getId() {
    return id;
  }

  public String getDescription() {
    return description;
  }
}
