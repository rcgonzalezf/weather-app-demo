package org.rcgonzalezf.weather.openweather.model;

// Gson
@SuppressWarnings("unused")
public class Wind {
  private double speed;

  private double deg;

  public double getSpeed() {
    return speed;
  }

  public double getDeg() {
    return deg;
  }

}

