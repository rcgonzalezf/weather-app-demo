package org.rcgonzalezf.weather.openweather.network;

public enum ErrorCode {
  EMPTY
}
